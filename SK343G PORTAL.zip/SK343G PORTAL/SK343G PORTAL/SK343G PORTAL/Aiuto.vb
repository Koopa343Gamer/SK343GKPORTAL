﻿Public Class Aiuto

    Private Sub RichTextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles RichTextBox1.TextChanged

    End Sub
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        My.Computer.Audio.Play("C:\Users\Alex\Documents\SK343GPORTALSFX\Awkward Moment.wav")
        EASTER_EGG.Show()
    End Sub

    Private Sub Aiuto_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        My.Computer.Audio.Play("C:\Users\Alex\Documents\SK343GPORTALSFX\Bamboo Hit #2 Sound Effect.wav")
    End Sub

    Private Sub Aiuto_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Alex\Documents\SK343GPORTALSFX\Funny Whoosh (Anime Sound) - Sound Effect for editing.wav")
    End Sub
End Class