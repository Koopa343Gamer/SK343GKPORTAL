﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Accesso
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtUsername = New System.Windows.Forms.TextBox()
        Me.Usernamelbl = New System.Windows.Forms.Label()
        Me.Passlbl = New System.Windows.Forms.Label()
        Me.TxtPass = New System.Windows.Forms.TextBox()
        Me.Accedi = New System.Windows.Forms.Button()
        Me.VerificaPass = New System.Windows.Forms.Label()
        Me.Aiuto = New System.Windows.Forms.Button()
        Me.VerificaPass2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TxtUsername
        '
        Me.TxtUsername.Location = New System.Drawing.Point(175, 12)
        Me.TxtUsername.Name = "TxtUsername"
        Me.TxtUsername.Size = New System.Drawing.Size(100, 22)
        Me.TxtUsername.TabIndex = 0
        '
        'Usernamelbl
        '
        Me.Usernamelbl.AutoSize = True
        Me.Usernamelbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Usernamelbl.Location = New System.Drawing.Point(11, 12)
        Me.Usernamelbl.Name = "Usernamelbl"
        Me.Usernamelbl.Size = New System.Drawing.Size(158, 17)
        Me.Usernamelbl.TabIndex = 1
        Me.Usernamelbl.Text = "Username in SK343GK:"
        '
        'Passlbl
        '
        Me.Passlbl.AutoSize = True
        Me.Passlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Passlbl.Location = New System.Drawing.Point(54, 39)
        Me.Passlbl.Name = "Passlbl"
        Me.Passlbl.Size = New System.Drawing.Size(73, 17)
        Me.Passlbl.TabIndex = 2
        Me.Passlbl.Text = "Password:"
        '
        'TxtPass
        '
        Me.TxtPass.Location = New System.Drawing.Point(133, 39)
        Me.TxtPass.Name = "TxtPass"
        Me.TxtPass.Size = New System.Drawing.Size(108, 22)
        Me.TxtPass.TabIndex = 3
        Me.TxtPass.UseSystemPasswordChar = True
        '
        'Accedi
        '
        Me.Accedi.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Accedi.Location = New System.Drawing.Point(14, 67)
        Me.Accedi.Name = "Accedi"
        Me.Accedi.Size = New System.Drawing.Size(72, 30)
        Me.Accedi.TabIndex = 4
        Me.Accedi.Text = "Accedi"
        Me.Accedi.UseVisualStyleBackColor = True
        '
        'VerificaPass
        '
        Me.VerificaPass.AutoSize = True
        Me.VerificaPass.ForeColor = System.Drawing.Color.Red
        Me.VerificaPass.Location = New System.Drawing.Point(155, 82)
        Me.VerificaPass.Name = "VerificaPass"
        Me.VerificaPass.Size = New System.Drawing.Size(120, 17)
        Me.VerificaPass.TabIndex = 5
        Me.VerificaPass.Text = "Verifica Password"
        Me.VerificaPass.Visible = False
        '
        'Aiuto
        '
        Me.Aiuto.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Aiuto.Location = New System.Drawing.Point(108, 72)
        Me.Aiuto.Name = "Aiuto"
        Me.Aiuto.Size = New System.Drawing.Size(33, 25)
        Me.Aiuto.TabIndex = 6
        Me.Aiuto.Text = "?"
        Me.Aiuto.UseVisualStyleBackColor = True
        '
        'VerificaPass2
        '
        Me.VerificaPass2.AutoSize = True
        Me.VerificaPass2.ForeColor = System.Drawing.Color.Green
        Me.VerificaPass2.Location = New System.Drawing.Point(155, 80)
        Me.VerificaPass2.Name = "VerificaPass2"
        Me.VerificaPass2.Size = New System.Drawing.Size(120, 17)
        Me.VerificaPass2.TabIndex = 7
        Me.VerificaPass2.Text = "Verifica Password"
        Me.VerificaPass2.Visible = False
        '
        'Accesso
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(294, 103)
        Me.Controls.Add(Me.VerificaPass2)
        Me.Controls.Add(Me.Aiuto)
        Me.Controls.Add(Me.VerificaPass)
        Me.Controls.Add(Me.Accedi)
        Me.Controls.Add(Me.TxtPass)
        Me.Controls.Add(Me.Passlbl)
        Me.Controls.Add(Me.Usernamelbl)
        Me.Controls.Add(Me.TxtUsername)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Accesso"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Accesso"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtUsername As System.Windows.Forms.TextBox
    Friend WithEvents Usernamelbl As System.Windows.Forms.Label
    Friend WithEvents Passlbl As System.Windows.Forms.Label
    Friend WithEvents TxtPass As System.Windows.Forms.TextBox
    Friend WithEvents Accedi As System.Windows.Forms.Button
    Friend WithEvents VerificaPass As System.Windows.Forms.Label
    Friend WithEvents Aiuto As System.Windows.Forms.Button
    Friend WithEvents VerificaPass2 As System.Windows.Forms.Label
End Class
