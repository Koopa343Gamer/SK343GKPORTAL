﻿Public Class EASTER_EGG

    Private Sub EASTER_EGG_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        'WORK ONLY MY PC My.Computer.Audio.Play("C:\Users\Alex\Documents\SK343GPORTALSFX\Breast Twitch.wav")
    End Sub

    Private Sub EASTER_EGG_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'WORK ONLY MY PC My.Computer.Audio.Play("C:\Users\Alex\Documents\SK343GPORTALSFX\Anime Shine Sound Effect.wav")
    End Sub

    Private Sub Label2_Click(sender As System.Object, e As System.EventArgs) Handles Label2.Click
        'WORK ONLY MY PC My.Computer.Audio.Play("C:\Users\Alex\Documents\SK343GPORTALSFX\Awkward Moment.wav")
        MsgBox("Hai trovato un segreto, ma è la password per accedere al portale. Ora inseriscila nel form di login. Penso che tu hai avuto un IQ di 100.", MsgBoxStyle.Information, "Sira 😀:")
    End Sub
End Class