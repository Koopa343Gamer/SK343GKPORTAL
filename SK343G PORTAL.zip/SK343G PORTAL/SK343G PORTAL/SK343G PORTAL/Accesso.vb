﻿Public Class Accesso

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Aiuto.Click
        MsgBox("Se tu ti stai chiedendo la password per accedere al portale, sappi che io non ti posso aiutare quindi arrangiati.", MsgBoxStyle.Information, "Sira avvisa dicendoti:")
        MsgBox("O se no guarda in giro nel programma. Arrivederci e ciao.😛", MsgBoxStyle.Exclamation, "Sira 😐:")
        MsgBox("Anzi ti canto una parte di Revenge, CREEPER AW MAN. Cause baby tonight. The Creepers tryin'to steal all our stuff again. LOL LMAO.", MsgBoxStyle.Critical, "Sira 😁:")
    End Sub

    Private Sub Accedi_Click(sender As System.Object, e As System.EventArgs) Handles Accedi.Click
        If TxtPass.Text = "siraloveyou" Then
            VerificaPass.Visible = False
            VerificaPass2.Visible = True
            VerificaPass2.Text = "Password giusta"
            MsgBox("Accesso riuscito con successo オタマシマスタ(me ne vado). ", MsgBoxStyle.Information, "Sira 😀:")
            Me.Hide()
        Else
            VerificaPass.Visible = True
            VerificaPass.Text = "Password errata"
            MsgBox("Accesso non riuscito password non corretta, se non la sai t'arrangi. Un unico aiuto che ti potrei dare è cliccare il tasto ❔(punto di domanda). ", MsgBoxStyle.Critical, "Sira 😥:")
        End If
    End Sub
End Class