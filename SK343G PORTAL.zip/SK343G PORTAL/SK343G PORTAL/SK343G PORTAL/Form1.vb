﻿Public Class Home

    Private Sub ChiudiToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ChiudiToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem1.Click
        Aiuto.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Accesso.ShowDialog()
    End Sub
End Class
