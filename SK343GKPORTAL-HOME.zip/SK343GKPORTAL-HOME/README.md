# SK343GKPORTAL
Questo è il programma (sviluppato da Sira) che viene usato nella stagione 2 pt.1 della serie K343G's School.
