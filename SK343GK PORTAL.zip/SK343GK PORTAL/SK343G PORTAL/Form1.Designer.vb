﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChiudiToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AiutoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformazioniToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TestoHome = New System.Windows.Forms.Label()
        Me.Usernamelbl = New System.Windows.Forms.Label()
        Me.TxtPass = New System.Windows.Forms.TextBox()
        Me.Lblpass = New System.Windows.Forms.Label()
        Me.BtnAccedi = New System.Windows.Forms.Button()
        Me.BtnAiuto = New System.Windows.Forms.Button()
        Me.VerificaPass = New System.Windows.Forms.Label()
        Me.VerificaPass2 = New System.Windows.Forms.Label()
        Me.AccessoPortale = New System.Windows.Forms.GroupBox()
        Me.HidePass = New System.Windows.Forms.RadioButton()
        Me.ShowPass = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.AiutoAccesso = New System.Windows.Forms.Label()
        Me.TxtUser = New System.Windows.Forms.TextBox()
        Me.LblUser = New System.Windows.Forms.Label()
        Me.BtnChiudiAccesso = New System.Windows.Forms.Button()
        Me.UsernameLabel = New System.Windows.Forms.Label()
        Me.LogoutPortal = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BtnInizia = New System.Windows.Forms.Button()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.AccessoPortale.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.FileToolStripMenuItem1, Me.ToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(566, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.FileToolStripMenuItem.Text = "WIP"
        Me.FileToolStripMenuItem.Visible = False
        '
        'FileToolStripMenuItem1
        '
        Me.FileToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChiudiToolStripMenuItem1})
        Me.FileToolStripMenuItem1.Name = "FileToolStripMenuItem1"
        Me.FileToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem1.Text = "File"
        '
        'ChiudiToolStripMenuItem1
        '
        Me.ChiudiToolStripMenuItem1.Name = "ChiudiToolStripMenuItem1"
        Me.ChiudiToolStripMenuItem1.Size = New System.Drawing.Size(109, 22)
        Me.ChiudiToolStripMenuItem1.Text = "Chiudi"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AiutoToolStripMenuItem, Me.InformazioniToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(24, 20)
        Me.ToolStripMenuItem1.Text = "?"
        '
        'AiutoToolStripMenuItem
        '
        Me.AiutoToolStripMenuItem.Name = "AiutoToolStripMenuItem"
        Me.AiutoToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.AiutoToolStripMenuItem.Text = "Aiuto"
        '
        'InformazioniToolStripMenuItem
        '
        Me.InformazioniToolStripMenuItem.Name = "InformazioniToolStripMenuItem"
        Me.InformazioniToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.InformazioniToolStripMenuItem.Text = "Informazioni"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(9, 23)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(540, 37)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Super Koopa343Gamer Kart's Portal"
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button1.Location = New System.Drawing.Point(234, 154)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(86, 37)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "ENTRA"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(43, 321)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(489, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "©Copyright Sira from IscrittiKoopasBrosYoshi. Ho dei problemi (si può incorrere i" & _
    "n errori)."
        '
        'TestoHome
        '
        Me.TestoHome.AutoSize = True
        Me.TestoHome.BackColor = System.Drawing.Color.Transparent
        Me.TestoHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TestoHome.ForeColor = System.Drawing.Color.White
        Me.TestoHome.Location = New System.Drawing.Point(110, 87)
        Me.TestoHome.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.TestoHome.Name = "TestoHome"
        Me.TestoHome.Size = New System.Drawing.Size(310, 25)
        Me.TestoHome.TabIndex = 4
        Me.TestoHome.Text = "Sira: Clicca INIZIA per cominciare!"
        '
        'Usernamelbl
        '
        Me.Usernamelbl.AutoSize = True
        Me.Usernamelbl.BackColor = System.Drawing.Color.Transparent
        Me.Usernamelbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Usernamelbl.ForeColor = System.Drawing.Color.White
        Me.Usernamelbl.Location = New System.Drawing.Point(11, 62)
        Me.Usernamelbl.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Usernamelbl.Name = "Usernamelbl"
        Me.Usernamelbl.Size = New System.Drawing.Size(108, 25)
        Me.Usernamelbl.TabIndex = 5
        Me.Usernamelbl.Text = "Username:"
        Me.Usernamelbl.Visible = False
        '
        'TxtPass
        '
        Me.TxtPass.Location = New System.Drawing.Point(300, 19)
        Me.TxtPass.Name = "TxtPass"
        Me.TxtPass.Size = New System.Drawing.Size(100, 20)
        Me.TxtPass.TabIndex = 6
        Me.TxtPass.UseSystemPasswordChar = True
        '
        'Lblpass
        '
        Me.Lblpass.AutoSize = True
        Me.Lblpass.Location = New System.Drawing.Point(238, 19)
        Me.Lblpass.Name = "Lblpass"
        Me.Lblpass.Size = New System.Drawing.Size(56, 13)
        Me.Lblpass.TabIndex = 7
        Me.Lblpass.Text = "Password:"
        '
        'BtnAccedi
        '
        Me.BtnAccedi.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.BtnAccedi.Location = New System.Drawing.Point(406, 16)
        Me.BtnAccedi.Name = "BtnAccedi"
        Me.BtnAccedi.Size = New System.Drawing.Size(58, 24)
        Me.BtnAccedi.TabIndex = 8
        Me.BtnAccedi.Text = "Accedi"
        Me.BtnAccedi.UseVisualStyleBackColor = True
        '
        'BtnAiuto
        '
        Me.BtnAiuto.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.BtnAiuto.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnAiuto.Location = New System.Drawing.Point(470, 16)
        Me.BtnAiuto.Name = "BtnAiuto"
        Me.BtnAiuto.Size = New System.Drawing.Size(61, 24)
        Me.BtnAiuto.TabIndex = 9
        Me.BtnAiuto.Text = "?"
        Me.BtnAiuto.UseVisualStyleBackColor = True
        '
        'VerificaPass
        '
        Me.VerificaPass.AutoSize = True
        Me.VerificaPass.ForeColor = System.Drawing.Color.Red
        Me.VerificaPass.Location = New System.Drawing.Point(217, 65)
        Me.VerificaPass.Name = "VerificaPass"
        Me.VerificaPass.Size = New System.Drawing.Size(91, 13)
        Me.VerificaPass.TabIndex = 10
        Me.VerificaPass.Text = "Verifica Password"
        Me.VerificaPass.Visible = False
        '
        'VerificaPass2
        '
        Me.VerificaPass2.AutoSize = True
        Me.VerificaPass2.ForeColor = System.Drawing.Color.Lime
        Me.VerificaPass2.Location = New System.Drawing.Point(219, 65)
        Me.VerificaPass2.Name = "VerificaPass2"
        Me.VerificaPass2.Size = New System.Drawing.Size(91, 13)
        Me.VerificaPass2.TabIndex = 11
        Me.VerificaPass2.Text = "Verifica Password"
        Me.VerificaPass2.Visible = False
        '
        'AccessoPortale
        '
        Me.AccessoPortale.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.AccessoPortale.Controls.Add(Me.HidePass)
        Me.AccessoPortale.Controls.Add(Me.ShowPass)
        Me.AccessoPortale.Controls.Add(Me.Label3)
        Me.AccessoPortale.Controls.Add(Me.AiutoAccesso)
        Me.AccessoPortale.Controls.Add(Me.TxtUser)
        Me.AccessoPortale.Controls.Add(Me.LblUser)
        Me.AccessoPortale.Controls.Add(Me.Lblpass)
        Me.AccessoPortale.Controls.Add(Me.VerificaPass2)
        Me.AccessoPortale.Controls.Add(Me.TxtPass)
        Me.AccessoPortale.Controls.Add(Me.VerificaPass)
        Me.AccessoPortale.Controls.Add(Me.BtnAccedi)
        Me.AccessoPortale.Controls.Add(Me.BtnAiuto)
        Me.AccessoPortale.ForeColor = System.Drawing.SystemColors.Control
        Me.AccessoPortale.Location = New System.Drawing.Point(12, 196)
        Me.AccessoPortale.Name = "AccessoPortale"
        Me.AccessoPortale.Size = New System.Drawing.Size(537, 122)
        Me.AccessoPortale.TabIndex = 12
        Me.AccessoPortale.TabStop = False
        Me.AccessoPortale.Text = "Autenticazione per il portale"
        Me.AccessoPortale.Visible = False
        '
        'HidePass
        '
        Me.HidePass.AutoSize = True
        Me.HidePass.Checked = True
        Me.HidePass.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.HidePass.Location = New System.Drawing.Point(412, 46)
        Me.HidePass.Name = "HidePass"
        Me.HidePass.Size = New System.Drawing.Size(124, 18)
        Me.HidePass.TabIndex = 18
        Me.HidePass.TabStop = True
        Me.HidePass.Text = "Nascondi password"
        Me.HidePass.UseVisualStyleBackColor = True
        '
        'ShowPass
        '
        Me.ShowPass.AutoSize = True
        Me.ShowPass.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ShowPass.Location = New System.Drawing.Point(300, 46)
        Me.ShowPass.Name = "ShowPass"
        Me.ShowPass.Size = New System.Drawing.Size(111, 18)
        Me.ShowPass.TabIndex = 17
        Me.ShowPass.Text = "Mostra password"
        Me.ShowPass.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(176, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(180, 20)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Aiuto sull'autenticazione"
        '
        'AiutoAccesso
        '
        Me.AiutoAccesso.AutoSize = True
        Me.AiutoAccesso.Location = New System.Drawing.Point(6, 106)
        Me.AiutoAccesso.Name = "AiutoAccesso"
        Me.AiutoAccesso.Size = New System.Drawing.Size(527, 13)
        Me.AiutoAccesso.TabIndex = 15
        Me.AiutoAccesso.Text = "Accedi al portale inserendo l'username e la password. Come username metti quello " & _
    "del tuo profilo su SK343GK."
        '
        'TxtUser
        '
        Me.TxtUser.Location = New System.Drawing.Point(127, 19)
        Me.TxtUser.Name = "TxtUser"
        Me.TxtUser.Size = New System.Drawing.Size(97, 20)
        Me.TxtUser.TabIndex = 13
        '
        'LblUser
        '
        Me.LblUser.AutoSize = True
        Me.LblUser.Location = New System.Drawing.Point(6, 16)
        Me.LblUser.Name = "LblUser"
        Me.LblUser.Size = New System.Drawing.Size(122, 13)
        Me.LblUser.TabIndex = 12
        Me.LblUser.Text = "Username in SK343GK: "
        '
        'BtnChiudiAccesso
        '
        Me.BtnChiudiAccesso.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.BtnChiudiAccesso.Location = New System.Drawing.Point(234, 154)
        Me.BtnChiudiAccesso.Name = "BtnChiudiAccesso"
        Me.BtnChiudiAccesso.Size = New System.Drawing.Size(86, 37)
        Me.BtnChiudiAccesso.TabIndex = 13
        Me.BtnChiudiAccesso.Text = "CHIUDI"
        Me.BtnChiudiAccesso.UseVisualStyleBackColor = True
        Me.BtnChiudiAccesso.Visible = False
        '
        'UsernameLabel
        '
        Me.UsernameLabel.AutoSize = True
        Me.UsernameLabel.BackColor = System.Drawing.Color.Transparent
        Me.UsernameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UsernameLabel.ForeColor = System.Drawing.Color.White
        Me.UsernameLabel.Location = New System.Drawing.Point(124, 67)
        Me.UsernameLabel.Name = "UsernameLabel"
        Me.UsernameLabel.Size = New System.Drawing.Size(83, 20)
        Me.UsernameLabel.TabIndex = 14
        Me.UsernameLabel.Text = "Username"
        Me.UsernameLabel.Visible = False
        '
        'LogoutPortal
        '
        Me.LogoutPortal.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.LogoutPortal.Location = New System.Drawing.Point(327, 154)
        Me.LogoutPortal.Name = "LogoutPortal"
        Me.LogoutPortal.Size = New System.Drawing.Size(96, 36)
        Me.LogoutPortal.TabIndex = 15
        Me.LogoutPortal.Text = "DISCONETTITI"
        Me.LogoutPortal.UseVisualStyleBackColor = True
        Me.LogoutPortal.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(124, 118)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(208, 20)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Giocatori collegati al portale:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.Control
        Me.Label5.Location = New System.Drawing.Point(16, 123)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Solo nell'animazione"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(221, 64)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(311, 23)
        Me.ProgressBar1.Step = 20
        Me.ProgressBar1.TabIndex = 18
        Me.ProgressBar1.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 25
        '
        'BtnInizia
        '
        Me.BtnInizia.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.BtnInizia.Location = New System.Drawing.Point(234, 154)
        Me.BtnInizia.Name = "BtnInizia"
        Me.BtnInizia.Size = New System.Drawing.Size(87, 37)
        Me.BtnInizia.TabIndex = 19
        Me.BtnInizia.Text = "INIZIA"
        Me.BtnInizia.UseVisualStyleBackColor = True
        '
        'Timer2
        '
        Me.Timer2.Interval = 25
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlText
        Me.ClientSize = New System.Drawing.Size(566, 345)
        Me.Controls.Add(Me.BtnInizia)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LogoutPortal)
        Me.Controls.Add(Me.UsernameLabel)
        Me.Controls.Add(Me.BtnChiudiAccesso)
        Me.Controls.Add(Me.AccessoPortale)
        Me.Controls.Add(Me.Usernamelbl)
        Me.Controls.Add(Me.TestoHome)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Home"
        Me.Text = "Super Koopa343Gamer Kart's Portal"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.AccessoPortale.ResumeLayout(False)
        Me.AccessoPortale.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TestoHome As System.Windows.Forms.Label
    Friend WithEvents Usernamelbl As System.Windows.Forms.Label
    Friend WithEvents InformazioniToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AiutoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TxtPass As System.Windows.Forms.TextBox
    Friend WithEvents Lblpass As System.Windows.Forms.Label
    Friend WithEvents BtnAccedi As System.Windows.Forms.Button
    Friend WithEvents BtnAiuto As System.Windows.Forms.Button
    Friend WithEvents VerificaPass As System.Windows.Forms.Label
    Friend WithEvents VerificaPass2 As System.Windows.Forms.Label
    Friend WithEvents AccessoPortale As System.Windows.Forms.GroupBox
    Friend WithEvents BtnChiudiAccesso As System.Windows.Forms.Button
    Friend WithEvents LblUser As System.Windows.Forms.Label
    Friend WithEvents TxtUser As System.Windows.Forms.TextBox
    Friend WithEvents UsernameLabel As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents AiutoAccesso As System.Windows.Forms.Label
    Friend WithEvents HidePass As System.Windows.Forms.RadioButton
    Friend WithEvents ShowPass As System.Windows.Forms.RadioButton
    Friend WithEvents LogoutPortal As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents BtnInizia As System.Windows.Forms.Button
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents FileToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChiudiToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem

End Class
