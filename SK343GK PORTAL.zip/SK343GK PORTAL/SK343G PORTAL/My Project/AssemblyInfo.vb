﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Le informazioni generali relative a un assembly sono controllate dal seguente 
' insieme di attributi. Per modificare le informazioni associate a un assembly
' è necessario modificare i valori di questi attributi.

' Controllare i valori degli attributi dell'assembly

<Assembly: AssemblyTitle("SK343G PORTAL")> 
<Assembly: AssemblyDescription("Portale per SuperKoopa343Gamer Kart")> 
<Assembly: AssemblyCompany("Sira, IscrittiKoopasBrosYoshi")> 
<Assembly: AssemblyProduct("SK343G PORTAL")> 
<Assembly: AssemblyCopyright("Copyright ©  2021 Sira IscrittiKoopasBrosYoshi")> 
<Assembly: AssemblyTrademark("All Rights Reseved IKBY")> 

<Assembly: ComVisible(False)>

'Se il progetto viene esposto a COM, il GUID seguente verrà utilizzato come ID della libreria dei tipi
<Assembly: Guid("65c65e1d-e212-45ae-bc6d-3f5844d5c368")> 

' Le informazioni sulla versione di un assembly sono costituite dai seguenti quattro valori:
'
'      Numero di versione principale
'      Numero di versione secondario 
'      Numero build
'      Revisione
'
' È possibile specificare tutti i valori oppure impostare valori predefiniti per i numeri relativi alla revisione e alla build 
' utilizzando l'asterisco (*) come descritto di seguito:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
