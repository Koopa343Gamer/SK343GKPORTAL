﻿Public Class About

    Private Sub LinkLabel1_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://www.reddit.com/r/IKBY/")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("https://sites.google.com/view/iscrittik343gyt")
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        Process.Start("https://aleregamer.wixsite.com/website")
    End Sub

    Private Sub LinkLabel4_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        Process.Start("https://t.me/iscrittikoopasbrosyoshi")
    End Sub

    Private Sub LinkLabel5_LinkClicked(sender As System.Object, e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel5.LinkClicked
        Process.Start("https://discord.gg/steBWC9")
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs)
        Aiuto.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Process.Start("https://www.microsoft.com/it-it/d/windows-10-home/d76qx4bznwk4?rtc=1&activetab=pivot%3aoverviewtab")
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Process.Start("https://www.microsoft.com/it-it/windows/windows-7-end-of-life-support-information")
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Button4.Visible = False
        Label14.Visible = True
    End Sub

    Private Sub About_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Button4.Visible = True
        Label14.Visible = False
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        Changelog.ShowDialog()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Process.Start("https://github.com/Koopa343Gamer/SK343GKPORTAL")
    End Sub
End Class