﻿Public Class Home
    Dim Testo As String = My.Computer.FileSystem.CurrentDirectory
    Dim Avviato As Boolean = False

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Button1.Visible = False
        AccessoPortale.Visible = True
        BtnChiudiAccesso.Visible = True
        VerificaPass.Visible = False
        VerificaPass2.Visible = False
        If TxtPass.Text = "siraloveyou" Then
            LogoutPortal.Visible = True
        End If
    End Sub
    Private Sub InformazioniToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles InformazioniToolStripMenuItem.Click
        About.ShowDialog()
    End Sub

    Private Sub AiutoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles AiutoToolStripMenuItem.Click
        Aiuto.ShowDialog()
    End Sub

    Private Sub BtnAiuto_Click(sender As System.Object, e As System.EventArgs) Handles BtnAiuto.Click
        'WORK ONLY ON WINDOWS 10 (EMOJI TEXT)
        If TxtPass.Text = "siraloveyou" Then
            MsgBox("Sei dentro il portale e puoi cambiare l'username se vuoi. Ora divertiti nel portale e ciao.", MsgBoxStyle.Information, "Sira ti saluta per essere entrato/a nel portale")
        Else
            MsgBox("Se tu ti stai chiedendo la password per accedere al portale, sappi che io non ti posso aiutare quindi arrangiati.", MsgBoxStyle.Information, "Sira avvisa dicendoti")
            MsgBox("O se no guarda in giro nel programma. Arrivederci e ciao.😛", MsgBoxStyle.Exclamation, "Sira 😐")
            MsgBox("Anzi ti canto una parte di Revenge, CREEPER AW MAN. Cause baby tonight. The Creepers tryin'to steal all our stuff again. LOL LMAO.", MsgBoxStyle.Critical, "Sira 😁")
        End If
    End Sub

    Private Sub BtnAccedi_Click(sender As System.Object, e As System.EventArgs) Handles BtnAccedi.Click
        If TxtPass.Text = "siraloveyou" Then
            VerificaPass.Visible = False
            VerificaPass2.Visible = True
            VerificaPass2.Text = "Password giusta"
            TestoHome.Visible = False
            BtnChiudiAccesso.Visible = False
            LogoutPortal.Visible = False
            BtnAiuto.Text = "Da Sira"
            MsgBox("Accesso riuscito con successo, username salvato オタマシマスタ (me ne vado). ", MsgBoxStyle.Information, "Sira 😀")
            AccessoPortale.Visible = False
            Button1.Visible = True
            Button1.Text = "MODIFICA"
            Usernamelbl.Visible = True
            UsernameLabel.Visible = True
            UsernameLabel.Text = TxtUser.Text
            TxtPass.Enabled = False
            If Not TxtUser.Text = "" Then
                BtnAccedi.Text = "Salva"
            End If
            ShowPass.Visible = False
            HidePass.Visible = False
            Me.Text = "SK343GK's Portal Accesso eseguito come: " & TxtUser.Text
            Label3.Visible = False
            AiutoAccesso.Text = "Clicca sul tasto di fianco al tasto Salva"
        Else
            VerificaPass2.Visible = False
            VerificaPass.Visible = True
            VerificaPass.Text = "Password errata"
            MsgBox("Accesso non riuscito password non corretta, se non la sai t'arrangi. Un unico aiuto che ti potrei dare è cliccare il tasto ❔(punto di domanda) e andare su Aiuto. ", MsgBoxStyle.Critical, "Sira 😥")
        End If
    End Sub

    Private Sub Home_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Sei sicuro di voler uscire", "Sira dice:", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) = Windows.Forms.DialogResult.Yes Then
            Timer2.Start()
            ProgressBar1.Visible = True
            Button1.Visible = False
            ProgressBar1.Value = 0
            TestoHome.Text = "Sira's School.exe si sta chiudendo..."
            MsgBox("Arrivederci utente, per essere venuto/a nel portale di Super Koopa343Gamer Kart's Portal. Ah quando apri questo programma io avvio Sira School.exe che è un programma associato a me che lo uso per monitorare l'uso di questo programma, quando chiudi questo programma io chiudo Sira School.exe. Praticamente è come se ti entro nel computer. Ci vediamo alla prossima e Arigato komotemasu (Grazie).", MsgBoxStyle.Information, "Sira dice salutando:")
            TestoHome.Text = "Sira: Arrivederci!"
            ProgressBar1.Visible = False
            Dim proc = Process.GetProcessesByName("Sira's School")
            For i As Integer = 0 To proc.Count - 1
                proc(i).CloseMainWindow()
            Next i
            If Avviato = True Then
                MsgBox("Sono uscita perchè devo andare nel mio computer. Ciao.", MsgBoxStyle.Critical, "Sira's School.exe Uscita")
            End If

        Else
            e.Cancel = True
        End If

    End Sub

    Private Sub Home_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Button1.Visible = False
        VerificaPass.Visible = False
        VerificaPass2.Visible = False
        TxtPass.Text = ""
    End Sub

    Private Sub BtnChiudiAccesso_Click(sender As System.Object, e As System.EventArgs) Handles BtnChiudiAccesso.Click
        Button1.Visible = True
        AccessoPortale.Visible = False
        BtnChiudiAccesso.Visible = False
        LogoutPortal.Visible = False
    End Sub

    Private Sub ShowPass_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles ShowPass.CheckedChanged
        TxtPass.UseSystemPasswordChar = False
    End Sub

    Private Sub HidePass_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles HidePass.CheckedChanged
        TxtPass.UseSystemPasswordChar = True
    End Sub

    Private Sub LogoutPortal_Click(sender As System.Object, e As System.EventArgs) Handles LogoutPortal.Click
        Button1.Text = "ENTRA"
        TxtPass.Text = ""
        TxtUser.Text = ""
        TestoHome.Visible = True
        Usernamelbl.Visible = False
        UsernameLabel.Visible = False
        Me.Text = "Super Koopa343Gamer Kart's Portal"
        LogoutPortal.Visible = False
        ShowPass.Visible = True
        HidePass.Visible = True
        TxtPass.Enabled = True
        BtnAiuto.Text = "?"
        BtnAccedi.Text = "Accedi"
        Label3.Visible = True
        AiutoAccesso.Text = "Accedi al portale inserendo l'username e la password. Come username metti quello del tuo profilo su SK343GK."
    End Sub

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            Button1.Visible = True
            TestoHome.Text = "Sira: Sto aspettando che tu acceda!"
            Testo = Testo.Remove(Len(My.Computer.FileSystem.CurrentDirectory) - 9) & "Sira's School\Sira's School\bin\Release\Sira's School.exe"
            Process.Start(Testo)
            Avviato = True
            MsgBox("Sono entrata per sbirciare l'uso di questo programma.", MsgBoxStyle.Information, "Sira's School.exe Entrata")
            ProgressBar1.Visible = False
        End If
    End Sub
    Private Sub Timer2_Tick(sender As System.Object, e As System.EventArgs) Handles Timer2.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 100 Then
            Timer2.Stop()
            BtnInizia.Visible = False
        End If
    End Sub
    Private Sub BtnInizia_Click(sender As System.Object, e As System.EventArgs) Handles BtnInizia.Click
        Timer1.Start()
        Button1.Visible = False
        ProgressBar1.Visible = True
        TestoHome.Text = "Sira's School.exe si sta avviando..."
        BtnInizia.Visible = False
    End Sub

    Private Sub ChiudiToolStripMenuItem1_Click(sender As System.Object, e As System.EventArgs) Handles ChiudiToolStripMenuItem1.Click
        Me.Close()
    End Sub

End Class
