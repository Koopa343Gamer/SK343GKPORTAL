﻿Module Module1

    Sub Main()
        Console.WriteLine("Sira 's School Started and i monitoring your use of this program.")
        Console.WriteLine("Sira 's School When you closing the main program I quit.")
        Console.ReadLine()
    End Sub

End Module
